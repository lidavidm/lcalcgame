
/**
 *	Lambda Calc V3
 *  --------------
 * 	Foundation structures
 */

 const EMPTY_EXPR_WIDTH = 50;
 const DEFAULT_EXPR_HEIGHT = 50;
 const DEFAULT_CORNER_RAD = 20;
 var DEFAULT_RENDER_CTX = null;

/** A generic expression. Could be a lambda expression, could be an if statement, could be a for.
    In general, anything that takes in arguments and can reduce to some other value based on those arguments. */
class Expression extends RoundedRect {
    constructor(holes=[]) {
        super(0, 0, EMPTY_EXPR_WIDTH, DEFAULT_EXPR_HEIGHT, DEFAULT_CORNER_RAD);

        this.holes = holes;
        this.padding = 10;
        this._size = { w:EMPTY_EXPR_WIDTH, h:DEFAULT_EXPR_HEIGHT };

        if (this.holes) {
            var _this = this;
            this.holes.forEach((hole) => {
                _this.addChild(hole);
            });
        }
    }
    equals(otherNode) {
        if (otherNode instanceof Expression && this.holes.length === otherNode.holes.length) {
            if (this.holes.length === 0)
                return this.value === otherNode.value;
            else {
                var b = true;
                for(let i = 0; i < this.holes.length; i++)
                    b &= this.holes[i].value === otherNode[i].value;
                return b;
            }
        }
        return false;
    }
    clone(parent=null) {
        var c = super.clone(parent);
        var children = c.children;
        c.children = [];
        c.holes = [];
        children.forEach((child) => c.addArg(child));
        return c;
    }

    addArg(arg) {
        this.holes.push(arg);
        this.addChild(arg);
    }
    removeArg(arg) {
        var idx = this.holes.indexOf(arg);
        if (idx > -1) {
            this.holes.splice(idx, 1); // remove 1 elem @ idx
            this.update();
            //this.stage.draw();
        } else console.error('@ removeArg: Could not find arg ', arg, ' in expression.');
    }
    swap(arg, anotherArg) {
        if (!arg || !anotherArg) return;
        var i = this.holes.indexOf(arg);
        if (i > -1) {
            anotherArg.pos = arg.pos;
            anotherArg.dragging = false;
            this.holes.splice(i, 1, anotherArg);
            anotherArg.parent = this;
            anotherArg.scale = { x:0.85, y:0.85 };
            anotherArg.onmouseleave();
            anotherArg.onmouseup();
            arg.parent = null;
            this.update();
        }
        else console.log('Cannot swap: Argument ', arg, ' not found in parent.');
    }

    get holeCount() {
        return this.holes ? this.holes.length : 0;
    }

    // Sizes to match its children.
    get size() {

        var width = 0;
        var padding = this.padding;
        var sizes = this.getHoleSizes();
        var scale_x = this.scale.x;

        if (sizes.length === 0) return { w:this._size.w, h:this._size.h };

        sizes.forEach((s) => {
            width += s.w + padding;
        });
        width += padding; // the end

        //if(this.color === 'red') width *= 0.8;
        return { w:width, h:DEFAULT_EXPR_HEIGHT };
    }

    getHoleSizes() {
        if (!this.holes || this.holes.length === 0) return [];
        var sizes = [];
        this.holes.forEach((expr) => {
            var size = expr ? expr.size : {w:EMPTY_EXPR_WIDTH, h:DEFAULT_EXPR_HEIGHT};
            size.w *= expr.scale.x;
            sizes.push(size);
        });
        return sizes;
    }

    update() {
        var padding = this.padding;
        var x = padding;
        var y = this.size.h / 2.0;
        var _this = this;
        this.children = [];
        this.holes.forEach((expr) => _this.addChild(expr));
        this.holes.forEach((expr) => { // Update hole expression positions.
            expr.anchor = { x:0, y:0.5 };
            expr.pos = { x:x, y:y };
            expr.scale = { x:0.85, y:0.85 };
            expr.update();
            x += expr.size.w * expr.scale.x + padding;
        });
        this.children = this.holes; // for rendering
    }

    // Apply arguments to expression
    apply(args) {
        // ... //
    }

    // Apply a single argument at specified arg index
    applyAtIndex(idx, arg) {
        // ... //
    }

    // Tests whether this expression is equal to another.
    equals(e2) {
        // ... //
    }

    // Reduce this expression to another.
    // * Returns the newly built expression. Leaves this expression unchanged.
    reduce(options=undefined) {
        return this;
    }
    // * Swaps this expression for its reduction (if one exists) in the expression hierarchy.
    performReduction() {
        var reduced_expr = this.reduce();
        if (reduced_expr && reduced_expr != this) { // Only swap if reduction returns something > null.

            console.warn('performReduction with ', this, reduced_expr);

            this.stage.saveState();
            Logger.log('state-save', this.stage.toString());

            // Log the reduction.
            let reduced_expr_str;
            if (Array.isArray(reduced_expr))
                reduced_expr_str = reduced_expr.reduce((prev,curr) => (prev + curr.toString() + ' '), '').trim();
            else reduced_expr_str = reduced_expr.toString();
            Logger.log('reduction', { 'before':this.toString(), 'after':reduced_expr_str });

            var parent = this.parent ? this.parent : this.stage;
            reduced_expr.ignoreEvents = this.ignoreEvents; // the new expression should inherit whatever this expression was capable of as input
            parent.swap(this, reduced_expr);

            if (reduced_expr.parent) {
                var try_reduce = reduced_expr.parent.reduceCompletely();
                if (try_reduce != reduced_expr.parent && try_reduce !== null) {
                    Animate.blink(reduced_expr.parent, 400, [0,1,0]);
                }
            }
        }
    }
    reduceCompletely() { // Try to reduce this expression and its subexpressions as completely as possible.
        var e = this;
        var prev_holes = e.holes;
        //e.parent = this.parent;
        if (e.children.length === 0) return e.reduce();
        else {
            e.holes = e.holes.map((hole) => {
                if (hole instanceof Expression)
                    return hole.reduceCompletely();
                else
                    return hole;
            });
            console.warn('Reduced: ', e.holes);
            e.children = [];
            e.holes.forEach((hole) => e.addChild(hole));
            var red = e.reduce();
            e.holes = prev_holes;
            e.holes.forEach((hole) => e.addChild(hole));
            return red;
        }
    }

    detach() {
        if (this.parent) {
            var ghost_expr = new MissingExpression(this);
            var _this = this;
            var stage = this.parent.stage;
            this.parent.swap(this, ghost_expr);
            stage.add(this);
            stage.bringToFront(this);
            this.shell = ghost_expr;
        }
    }

    onmousedrag(pos) {
        super.onmousedrag(pos);
        this.pos = pos;
        if (!this.dragging) {
            this.detach();
            this.stage.bringToFront(this);
            this.dragging = true;
        }
    }
    onmouseup(pos) {
        if (this.dragging && this.shell) {
            if(!this.parent) this.scale = { x:1, y:1 };
            this.shell = null;
            //this.shell.stage.remove(this);
            //this.shell.stage = null;
            //this.shell.parent.swap(this.shell, this); // put it back
            //this.shell = null;
        }
        this.dragging = false;
    }

    // The value (if any) this expression represents.
    value() { return undefined; }
    toString() {
        if (this.holes.length === 1) return this.holes[0].toString();
        let s = '(';
        for (let i = 0; i < this.holes.length; i++) {
            if (i > 0) s += ' ';
            s += this.holes[i].toString();
        }
        return s + ')';
    }
}

class MissingExpression extends Expression {
    constructor(expr_to_miss) {
        super([]);
        if (!expr_to_miss) expr_to_miss = new Expression();
        this.shadowOffset = -1; // inner
        this.color = '#555555';
        this._size = { w:expr_to_miss.size.w, h:expr_to_miss.size.h };
        this.ghost = expr_to_miss;
    }
    onmousedrag(pos) { } // disable drag
    ondropenter(node, pos) {
        this.onmouseenter(pos);
    }
    ondropexit(node, pos) {
        this.onmouseleave(pos);
    }
    ondropped(node, pos) {
        super.ondropped(node, pos);
        if (node.dragging) { // Reattach node.
            Resource.play('pop');
            node.stage.remove(node);
            this.parent.swap(this, node); // put it back

            // Blink red if total reduction is not possible with this config.
            /*var try_reduce = node.parent.reduceCompletely();
            if (try_reduce == node.parent || try_reduce === null) {
                Animate.blink(node.parent, 400, [1,0,0]);
            }*/

            // Blink blue if reduction is possible with this config.
            var try_reduce = node.parent.reduceCompletely();
            if (try_reduce != node.parent && try_reduce !== null) {
                Animate.blink(node.parent, 400, [0,1,0]);
            }
        }
    }

    toString() { return '_'; }
}

class TextExpr extends Expression {
    constructor(txt, font='Consolas', fontSize=35) {
        super();
        this.text = txt;
        this.font = font;
        this.fontSize = fontSize; // in pixels
        this.color = 'black';
    }
    get size() {
        var ctx = this.ctx || GLOBAL_DEFAULT_CTX;
        if (!ctx || !this.text || this.text.length === 0) {
            console.error('Cannot size text: No context.');
            return { w:4, h:this.fontSize };
        }
        ctx.font = this.contextFont;
        var measure = ctx.measureText(this.text);
        return { w:measure.width, h:DEFAULT_EXPR_HEIGHT };
    }
    get contextFont() {
        return this.fontSize + 'px ' + this.font;
    }
    drawInternal(pos, boundingSize) {
        var ctx = this.ctx;
        var abs_scale = this.absoluteScale;
        ctx.save();
        ctx.font = this.contextFont;
        ctx.scale(abs_scale.x, abs_scale.y);
        ctx.fillStyle = this.color;
        ctx.fillText(this.text, pos.x / abs_scale.x, pos.y / abs_scale.y + 2.2 * this.fontSize * this.anchor.y);
        ctx.restore();
    }
    hits(pos, options) { return false; } // disable mouse events
    value() { return this.text; }
}

class BooleanPrimitive extends Expression {
    constructor(name) {
        super();
        var text = new TextExpr(name);
        text.pos = { x:0, y:0 };
        text.anchor = { x:-0.1, y:1.5 }; // TODO: Fix this bug.
        this.addArg(text);
    }
}
class TrueExpr extends BooleanPrimitive {
    constructor() {
        super('true');
    }
    value() { return true; }
    toString() { return 'true'; }
}
class FalseExpr extends BooleanPrimitive {
    constructor() {
        super('false');
    }
    value() { return false; }
    toString() { return 'false'; }
}
class EmptyExpr extends Expression {
    value() { return null; }
}

// An if statement.
class IfStatement extends Expression {
    constructor(cond, branch) {
        var if_text = new TextExpr('if');
        if_text.color = 'black';
        super([if_text, cond, branch]);
        this.color = 'LightBlue';
    }

    get cond() { return this.holes[1]; }
    get branch() { return this.holes[2]; }
    get emptyExpr() { return new EmptyExpr(); }

    onmouseclick(pos) {
        this.performReduction();
    }

    reduce() {
        if (!this.cond || !this.branch) return this; // irreducible
        var cond_val = this.cond.value();
        if (cond_val === true)          return this.branch; // return the inner branch
        else if (cond_val === false)    return this.emptyExpr; // disappear
        else                            return this; // something's not reducable...
    }

    value() {
        return undefined;
    }
    toString() {
        return '(if ' + this.cond.toString() + ' ' + this.branch.toString() + ')';
    }
}
class IfElseStatement extends IfStatement {
    constructor(cond, branch, elseBranch) {
        super(cond, branch);
        var txt = new TextExpr('else');
        txt.color = 'black';
        this.addArg(txt);
        this.addArg(elseBranch);
    }
    get elseBranch() { return this.holes[4]; }

    reduce() {
        if (!this.cond || !this.branch || !this.elseBranch) return this; // irreducible
        var cond_val = this.cond.value();
        console.log(this.cond, cond_val);
        if (cond_val === true)          return this.branch; // return the inner branch
        else if (cond_val === false)    return this.elseBranch; // disappear
        else                            return this; // something's not reducable...
    }

    toString() {
        return '(if ' + this.cond.toString() + ' ' + this.branch.toString() + ' ' + this.elseBranch.toString() + ')';
    }
}

// A boolean compare function like ==, !=, >, >=, <=, <.
class CompareExpr extends Expression {
    static operatorMap() {
        return { '==':'is', '!=':'≠' };
    }
    static textForFuncName(fname) {
        var map = CompareExpr.operatorMap();
        if (fname in map) return map[fname];
        else              return fname;
    }
    constructor(b1, b2, compareFuncName='==') {
        var compare_text = new TextExpr(CompareExpr.textForFuncName(compareFuncName));
        compare_text.color = 'black';
        super([b1, compare_text, b2]);
        this.funcName = compareFuncName;
        this.color = "HotPink";
    }
    get constructorArgs() { return [this.holes[0].clone(), this.holes[2].clone(), this.funcName]; }
    get leftExpr() { return this.holes[0]; }
    get rightExpr() { return this.holes[2]; }
    onmouseclick(pos) {
        console.log('Expressions are equal: ', this.compare());
        this.performReduction();
    }
    reduce() {
        var cmp = this.compare();
        if (cmp === true)       return new TrueExpr();
        else if (cmp === false) return new FalseExpr();
        else                    return this;
    }
    compare() {
        if (this.funcName === '==') {
            var lval = this.leftExpr.value();
            var rval = this.rightExpr.value();
            console.log('leftexpr', this.leftExpr.constructor.name, lval);
            console.log('rightexpr', this.rightExpr.constructor.name, rval);
            if (lval === undefined || rval === undefined) return undefined;
            return lval === rval;
        } else if (this.funcName === '!=') {
            return this.leftExpr.value() !== this.rightExpr.value();
        } else {
            console.warn('Compare function "' + this.funcName + '" not implemented.');
            return false;
        }
    }

    clone() {
        var c = super.clone();
        console.warn('cloned ', this.children);
        return c;
    }
    toString() {
        return '(' + this.funcName + ' ' + this.leftExpr.toString() + ' ' + this.rightExpr.toString() + ')';
    }
}

// Optional?
// Wrapper class to make arbitrary nodes into draggable expressions.
class VarExpr extends Expression {
    constructor(graphic_node) {
        super([graphic_node]);
        this.color = 'gold';
    }

    get color() { return super.color; }
    set color(clr) {
        this.holes[0].color = clr;
    }
    get delegateToInner() {
        return this.ignoreEvents || (!this.parent) || !(this.parent instanceof Expression);
    }

    //get size() { return this.holes[0].size; }
    hits(pos, options) {
        if(this.ignoreEvents) return null;
        if(this.holes[0].hits(pos, options)) return this;
        else return null;
    }
    onmouseenter(pos) {
        if (this.delegateToInner) this.holes[0].onmouseenter(pos);
        else super.onmouseenter(pos);
    }
    onmouseleave(pos) {
        if (!this.delegateToInner) super.onmouseleave(pos);
        this.holes[0].onmouseleave(pos);
    }
    drawInternal(pos, boundingSize) {
        if (!this.delegateToInner) {
            this._color = '#777';
            super.drawInternal(pos, boundingSize);
        }
    }
    value() { return this.holes[0].value(); }
}
class StarExpr extends VarExpr {
    constructor(x, y, rad, pts=5) {
        super(new Star(x, y, rad, pts));
    }
    toString() { return 'star'; }
}
class CircleExpr extends VarExpr {
    constructor(x, y, rad) {
        super(new Circle(x, y, rad));
    }
    toString() { return 'circle'; }
}
class PipeExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Pipe(x, y, w, h-12));
    }
    toString() { return 'pipe'; }
}
class TriangleExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Triangle(x, y, w, h));
    }
    toString() { return 'triangle'; }
}
class RectExpr extends VarExpr {
    constructor(x, y, w, h) {
        super(new Rect(x, y, w, h));
    }
    toString() { return 'diamond'; }
}
class ImageExpr extends VarExpr {
    constructor(x, y, w, h, resource_key) {
        super(new ImageRect(x, y, w, h, resource_key));
        this._image = resource_key;
    }
    get image() { return this._image; }
    set image(img) {
        this._image = img;
        this.children[0].image = img;
    }
    toString() { return this._image; }
}


// A while loop.
/* OLD -- class WhileLoop extends IfStatement {
    reduce() {
        if (!this.cond || !this.branch) return this; // irreducible
        else if (this.cond.value()) {
            this.branch.execute();
            return this; // step the branch, then return the same loop (irreducible)
        }
        else return this.emptyExpr;
    }
}

// A boolean expression. Can && or || or !.
class BooleanExpr extends Expression {
    constructor(b1, b2) {
        super(b1 || b2 ? [b1, b2] : [new TrueExpr(), new TrueExpr()]);
        this.OPTYPE = { AND:0, OR:1, NOT:2 };
        this.op = this.OPTYPE.AND;
    }

    // Change these when you subclass.
    get trueExpr() { return new TrueExpr(); }
    get falseExpr() { return new FalseExpr(); }

    // Reduces to TrueExpr or FalseExpr
    reduce() {
        var v = this.value();
        if (v) return this.trueExpr;
        else   return this.falseExpr;
    }

    value() {
        switch (this.op) {
            case this.OPTYPE.AND:
                return b1.value() && b2.value();
            case this.OPTYPE.OR:
                return b1.value() || b2.value();
            case this.OPTYPE.NOT:
                return !b1.value(); }
        console.error('Invalid optype.');
        return false;
    }
}*/
