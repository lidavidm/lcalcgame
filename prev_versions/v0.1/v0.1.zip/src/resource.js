
// USAGE EXAMPLE: Resource.audio('pop');
var Resource = (() => {

    const __RESOURCE_PATH = 'resources/';
    const __AUDIO_PATH = __RESOURCE_PATH + 'audio/';
    const __GRAPHICS_PATH = __RESOURCE_PATH + 'graphics/';
    var audioRsc = {};
    var imageRsc = {};
    var animPresets = {};
    var levels = [];
    var loadAudio = (alias, filename) => {
        var audio = new Audio(__AUDIO_PATH + filename);
        audioRsc[alias] = audio;
    };
    var loadImage = (alias, filename) => {
        var img = new Image();
        img.src = __GRAPHICS_PATH + filename;
        img.alt = alias;
        imageRsc[alias] = img;
    };
    var loadImageSequence = (alias, filename, range) => {
        let a = filename.split('.');
        let name = a[0];
        let ext = a[1];
        for (let i = range[0]; i <= range[1]; i++)
            loadImage(alias + i, name + i + '.' + ext);
    };
    var loadAnimation = (imageSeqAlias, range, duration) => {
        animPresets[imageSeqAlias] = Animation.forImageSequence(imageSeqAlias, range, duration);
    };

    // Add resources here:
    loadAudio('pop', 'pop.wav');
    loadAudio('poof', 'poof.wav');
    loadAudio('victory', '325805__wagna__collect.wav');
    loadImage('lambda-hole', 'lambda-hole.png');
    loadImage('lambda-pipe', 'lambda-pipe-closed.png');
    loadImage('lambda-pipe-open', 'lambda-pipe-open.png');
    loadImage('lambda-pipe-opening0', 'lambda-pipe-opening0.png');
    loadImage('lambda-pipe-opening1', 'lambda-pipe-opening1.png');

    // Loads poof0.png, poof1.png, ..., poof4.png (as poof0, poof1, ..., poof4, respectively).
    loadImageSequence('poof', 'poof.png', [0, 4]);

    // Load preset animations from image sequences.
    loadAnimation('poof', [0, 4], 120); // Cloud 'poof' animation for destructor piece.

    // Add levels here: (for now)
    // * The '/' character makes the following expression ignore mouse events (can't be drag n dropped). *
    levels.push(['(λx #x) (star)', 'star']);                                // T0
    levels.push(['(λx #x) (λy #y) (star) (star)', '(star) (star)']);          // T1
    levels.push(['(λy) (diamond) (star)', 'star']);                         // T2
    levels.push(['(λx #x) (λy) (diamond) (star)', 'star']);                 // T3
    levels.push(['(λx #x #x) (star)', '(star) (star)']);                      // T4
    levels.push(['(λx #x #x) (λy) (star) (diamond)', '(diamond) (diamond)']); // T5
    levels.push(['(λx #x #x) (λy #y) (λz) (star) (diamond) (diamond)', '(diamond) (diamond)']); // T6
    levels.push(['(λx (λy #y)) (star) (diamond)', 'star']);                 // T7
    levels.push(['(λx #x #x #x) (λy (λz #z)) (diamond) (diamond)', '(diamond) (diamond)']); // T8
    levels.push(['(λx #x #x #x) (λy #y #y) (λz #z) (λw) (star) (diamond)', '(star) (star) (star)']); // T9
    levels.push(['(λx #x #x #x) (λy #y #y) (λz #z) (λw) (star) (diamond)', 'star']); // T9*
    //levels.push(['(_) (star)', 'star']);                                    // T10
    levels.push(['(== /star /star)', 'true']);                                // T11
    levels.push(['(== _ /star) (star)', 'true']);                            // T12
    levels.push(['(== /diamond _) (diamond) (star) (λx)', 'true']);          // T13
    levels.push(['(star) (== /star _) (λx #x #x)', '(true) (true)']);            // T14
    levels.push(['(== /star /diamond)', 'false']);                            // T15
    levels.push(['(== _ /diamond) (star) (diamond) (λx)', 'false']);         // T16
    levels.push(['(== _ _) (star) (diamond)', 'false']);                    // T17
    levels.push(['(== /star _) (λx #x #x) (diamond) (diamond)', '(false) (false)']); // T18
    levels.push(['(== _ _) (λx #x #x) (λy #y #y) (star) (diamond)', '(true) (false)']); // T19

    /*levels.push(['(λx #x) (triangle)', 'triangle']);
    levels.push(['(λx #x) (λy #y)', '(λx #x)']);
    levels.push(['(if false /triangle /rect)', 'rect']);
    levels.push(['(if _ circle triangle) (!= /triangle _) (star)', 'star']);
    levels.push(['(if _ /star /circle) (== /triangle _) (rect) (λx λy #x) (triangle)', 'star']);*/

    //levels.push(Level.make('(if _ /rect false) (if _ /star /circle) (== /triangle _) (rect) (triangle)', 'star'));

    return { // TODO: Add more resource types.
        audio:audioRsc,
        image:imageRsc,
        getImage:(name) => imageRsc[name],
        getAudio:(name) => audioRsc[name],
        getAnimation:(name) => animPresets[name].clone(),
        play:(alias, volume) => {
            if(volume) audioRsc[alias].volume = volume;
            else audioRsc[alias].volume = 1.0;
            audioRsc[alias].play();
        },
        buildLevel:(idx, canvas) => Level.make(levels[idx][0], levels[idx][1]).build(canvas),
        level:levels
    };
})();
