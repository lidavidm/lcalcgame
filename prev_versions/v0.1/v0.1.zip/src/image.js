class ImageRect extends Rect {
    constructor(x, y, w, h, resource_key) {
        super(x,y,w,h);
        this.image = resource_key;
        this._offset = { x:0, y:0 };
    }
    get offset() { return { x:this._offset.x, y:this._offset.y }; }
    set offset(o) { this._offset = { x:o.x, y:o.y }; }
    drawInternal(pos, boundingSize) {
        if (!this.ctx || !this.image) {
            console.error('@ ImageRect: Cannot draw image ', this.image, ' in context ', this.ctx);
            return;
        }
        this.ctx.drawImage(Resource.getImage(this.image), pos.x + this._offset.x, pos.y + this._offset.y, boundingSize.w, boundingSize.h);
    }
}

// class Animation extends ImageRect {
//     static repeatStyle() {
//         return {
//             'ONCE':0,
//             'LOOP':1,
//             'PINGPONG':2
//         };
//     }
//     constructor(x, y, w, h) {
//         super(x,y,w,h,null);
//         this.frames = [];
//         this.currentFrame = 0;
//     }
//     addFrame(image_key, dur) {
//         this.frames.push( {image:image_key, duration:dur} );
//     }
//     get repeatStyle() { return this.repeat; }
//     set repeatStyle(style) { this.repeat = Animation.repeatStyle[style]; }
//     update
// }

// class Sprite extends ImageRect {
//     constructor(x, y, w, h, resource_key) {
//         super(x,y,w,h,resource_key);
//         this.states = {};
//     }
//     addTransitionEdge() {
//
//     }
// }
